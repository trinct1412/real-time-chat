var express = require("express");
var app = express();
var phpExpress = require('php-express')({
    binPath: 'php'
  });  
app.use(express.static("./public"));
app.set('views', '');
app.engine('php', phpExpress.engine);
app.set('view engine', 'php');
app.all(/.+\.php$/, phpExpress.router);
var server = require("http").Server(app);
var io = require("socket.io")(server);
server.listen(3000);
io.on("connection",function(socket){
    console.log("nguoi vua ket noi " + socket.id);
-    socket.on('disconnect',function(){
        console.log(socket.id + " vua thoat");
    })
    socket.on("cliend-send-to-sever",function(data){
        console.log(socket.id + " gui " + data);
        io.sockets.emit("sever-send-to-client",data);
    })
});

app.get("/",function(req,res){
    res.render("test");
});