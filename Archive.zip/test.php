<html lang="en">
<head>
<link rel="stylesheet" href="static/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<script src="js/node_modules/socket.io/node_modules/socket.io-client/dist/socket.io.js"></script>
  <script src="socket.io/socket.io.js"></script>
  <script>
        var socket = io( 'http://localhost:3000' );
        </script>
        
</head>
<body>
    <div id="conversation"></div>
        <input type="text" id="sendconversation">
        <button id="submit">submit</button>

<script>
    $(document).ready(function(){
        $("#submit").click(function(){
            socket.emit("cliend-send-to-sever",$('#sendconversation').val());
        });
    });
    socket.on("sever-send-to-client",function(data){
        $("#conversation").append(data);
    });
</script>
</body>
</html>